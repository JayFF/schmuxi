import pandas as pd
import yaml
from pylab import *
from scipy import *
from os import chdir
import os

def identify_peaks(spectrum, peak_model)
    '''Tries to identify the peaks in the spectra with theoretical
    predictions'''

    data = spectrum(list(spectrum)[1])

    peaks = 
